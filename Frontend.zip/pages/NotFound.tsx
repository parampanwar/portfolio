import { useRouter } from "next/router";
import { useEffect } from "react";
import Link from 'next/link'
const NotFound = () => {
  const location = useRouter();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-bold">404</h1>
        <p className="mb-4 text-xl text-gray-600">Oops! Page not found</p>
        <Link href="/" className="text-blue-500 underline hover:text-blue-700">
                Go Back Home
              </Link>
      </div>
    </div>
  );
};

export default NotFound;
